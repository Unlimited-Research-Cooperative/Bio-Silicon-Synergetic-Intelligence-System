screen /dev/ttyACM1 921600
